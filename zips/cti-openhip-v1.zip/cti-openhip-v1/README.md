
## Creating OpenHIP Statically Linked Binaries

### Prequisites

To build OpenHIP the CTI way you must have the following:

- Ubuntu 14.04.3 LTS
- OpenSSL 1.0.1f
- A zip of 'master' branch of OpenHIP from [here](https://bitbucket.org/openhip/openhip). We used commit f59947e (also known as the 'release-0.9' tag).

### Building Statically Linked

This instructions are taken from notes and may be incomplete at this time.

```
unzip openhip-openhip-f59947ed4a92.zip
cd openhip-openhip-f59947ed4a92/
export CFLAGS="-std=c99"
./bootstrap.sh
```

Before the next step edit the 'src/Makefile.am':
```
vim src/Makefile.am
```

Comment out the line for the "color-tests" as this breaks the build.

Move onto the next step:
```
./configure --prefix=/usr/local
```

We must edit the 'src/Makefile' now to statically link libraries:
```
vim src/Makefile
```

Add to the CFLAG variable "-static". Do the same for LDFLAGS.
Add to the end of the LIBS line "-ldl".

Next we run make:
```
make
```

This should complete and produce some binaries in 'src/'. Check their properties by running:
```
ldd hip
ldd hipstatus
ldd hitgen
```

These should output with no dynamic links, confirming the build was successful. These are now ready for use.

### Install on Box [Optional]

To continue to build on this box run the following:
```
sudo make install
```

This will install everything in '/usr/local/sbin/' and is now ready to be configured/run.

### Create a CTI OpenHIP package

Create/obtain the script titled 'stopHIP' which has the following contents:
```
#!/bin/bash

# get HIP pids
psOut=$(ps ax | grep hip)

# break the output into array
words=()
for word in $psOut; do
	# echo $word
	words+=( $word )
done

# grab the PID
hipPID=${words[0]}

# kill HIP
sudo kill -9 $hipPID
sudo rm /var/run/hip.pid
```

Also create an 'install.sh' script with the following contents:
```
#!/bin/bash

sudo cp * /usr/local/sbin/
cd /usr/local/sbin/
sudo ./hitgen
sudo ./hitgen -conf
sudo ./hitgen -publish
sudo chmod 755 /usr/local/etc/hip
sudo mv hip.conf *.pub.xml /usr/local/etc/hip/
```

Place the binaries 'hip', 'hipstatus','hitgen', 'stopHIP' and 'install.sh' into a folder titled "cti-openhip-v1" and zip up the folder using:
```
zip -r cti-openhip-v1.zip cti-openhip.v1/
```

We now have an install package for other hosts to use these binaries.

## Installing OpenHIP Binaries

Move the CTI supplied OpenHIP package to your host system, unzip it and run the installer.
```
unzip cti-openhip-v1.zip
cd cti-openhip-v1/
sudo ./install.sh
```

The script should handle the moving of the files. See next section if you wish to perform this manually.

### Manual Moving of Files

```
cd cti-openhip-v1/
sudo cp * /usr/local/sbin/
cd /usr/local/sbin/
sudo ./hitgen
sudo ./hitgen -conf
sudo ./hitgen -publish
sudo chmod 755 /usr/local/etc/hip
sudo mv hip.conf <hostname>_host_identities.pub.xml /usr/local/etc/hip/
```

## Setting Up & Configuring

If you have other '.pub.xml' files from other HIP hosts move them into '/usr/local/etc/hip/'.

We now will create a known hosts file using a different host identity file other than yours:
```
cd /usr/local/etc/hip/
sudo cp <other-hostname>_host_identities.pub.xml known_host_identities.xml
```

From every '.pub.xml' that isn't yours add in the host information to your 'known_host_identities.xml' file.

If you do not have HIP supported DNS then you must add the following to each entry in the file located directly below the LSI field:
```
<addr>ACTUAL_IP_ADDRESS_OF_HOST</addr>
```

## Using OpenHIP

To start OpenHIP usermode utility run the following:
```
cd /usr/local/sbin/
sudo ./hip -v
```

This will run HIP in the forground giving verbose logging to STDOUT.

To kill this instance of HIP hit 'Ctrl+Z' and then:
```
stopHIP
```

The 'stopHIP' utility will kill the process and remove the PID file.