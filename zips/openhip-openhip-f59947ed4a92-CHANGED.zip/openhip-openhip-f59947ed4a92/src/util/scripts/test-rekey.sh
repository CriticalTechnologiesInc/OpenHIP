#!/bin/sh
testpath=`dirname $0`
python $testpath/hiptest.py rekey 
